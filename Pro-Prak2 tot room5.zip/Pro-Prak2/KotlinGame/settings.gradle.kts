
rootProject.name = "KotlinGame"

