class Weapon(val name: String, var damageInflicted: Int) {

}